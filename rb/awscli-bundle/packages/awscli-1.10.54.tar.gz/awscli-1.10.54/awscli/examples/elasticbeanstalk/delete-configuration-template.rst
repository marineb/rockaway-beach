**To delete a configuration template**

The following command deletes a configuration template named ``my-template`` for an application named ``my-app``::

  aws elasticbeanstalk delete-configuration-template --template-name my-template --application-name my-app
